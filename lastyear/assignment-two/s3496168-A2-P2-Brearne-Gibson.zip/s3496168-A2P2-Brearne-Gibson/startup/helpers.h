/******************************************************************************
 * Student Name    : Brearne Gibson
 * RMIT Student ID : s3496168
 *
 * Startup code provided by Paul Miller for use in "Programming in C",
 * study period 4, 2019.
 *****************************************************************************/
#include "shared.h"
#ifndef HELPERS_H
#define HELPERS_H
/**
 * convenience function to malloc and copy the string passed in
 **/
char* strdup(const char*);
#endif
