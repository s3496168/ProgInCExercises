###############################################################################
# Student Name    : Brearne Gibson
# RMIT Student ID : s3496168
#
# Startup code provided by Paul Miller for use in "Programming in C",
# study period 4, 2019.
##############################################################################

How do we build your project? 
------------------------------
Started on deciding what would be needed in the main class, and implemented the 
functions appropriately. I then focuesd on initialising the system, then 
gettint the load/save features working, then the loop to print. I then freed
the memory.

What approaches did you use to solve the problems presented in this assignment?
-------------------------------------------------------------------------------
Testing code at each stage (one aread at a time) to identify any areas of issue,
so that each issue could be worked on individually and solved systematically.


