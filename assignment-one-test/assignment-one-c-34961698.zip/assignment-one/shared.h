#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#ifndef SHARED_H
#define SHARED_H
typedef enum boolean {
    FALSE,
    TRUE
} BOOLEAN;
#endif
