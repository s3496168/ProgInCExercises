/**README**/

Name: Brearne Gibson
Student ID number: s3496168
How to build and run the project: pease type main.c. All the other files needed
will compile at runtime automatically.
Implementation approach: I started following the curse material, then researched 
online where I could not find sufficient examples
Roadbocks and known issues: Some of the provided code is causing warnings (as 
the started code has not yet been used). Also, the while loop to terminate the 
program is not functioning fully yet

/**/
Update 10-01-2020

Menu now functioning from being called in
added guess a number and reverse a string
started on help menu and fold
