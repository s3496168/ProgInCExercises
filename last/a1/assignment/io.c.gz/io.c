/******************************************************************************
 * Student Name    :
 * RMIT Student ID :
 *
 * Startup code provided by Paul Miller for use in "Programming in C",
 * Assignment 1, study period 4, 2020.
 *****************************************************************************/
#include "io.h"

#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

/*constants*/
#define MIN_NUM_MENU_CHOICES 1
#define NUM_MENU_CHOICES 5
#define SCREENWIDTH 80
#define EXTRACHARS 2
#define PROMPTLEN 30
#define DECIMALINT 10
#define MAXINPUT 200

/**
 * function used to clear the buffer when you detect buffer overflow.
 * You may notice you cannot call this function from outside this module and
 * that's by design (that's why it's static). As you should be doing all input
 * and output code in this module, there is no need to have access to this
 * function outside of the io module.
 **/
static void clear_buffer(void) {
    int ch;
    while (ch = getc(stdin), ch != EOF && ch != '\n')
        ;
    clearerr(stdin);
}

/**
 * This function should display the menu for the system. It should validate
 * input and when there is an input error, display the error and reprompt
 * for input. It should then return a value representing what menu item was
 *selected.
 **/
enum menu_choice display_menu(void) {
    /*****************************START OF MENU
     * DISPLAY***************************/
    /*variables for menu display*/
    /*note the pointer-there to set memory*/
    char *heading;
    int strlen_heading;
    int count;
    /*variables for menu processing*/
    /*NOOLEAN located in shared.h*/
    BOOLEAN success = FALSE;
    int input;
    char line[SCREENWIDTH];
    int end;
    /*another pinter*/
    char *ptr;
    /*enum input_result located in io.h*/
    enum input_result result;
    /* delete this comment and return value and replace it with the proper
     * implementation of this function */

    char *menu_list[] = {
        "reverse a string",         "almost magic square",
        "greedy knapsack solution", "recursive bruteforce knapsack solution",
        "exit the program"};

    /*the heading*/
    heading = "Welcome to CPT220 Menu Solution";
    /*get the heading count for the loop below*/
    strlen_heading = strlen(heading);

    /*extra line for spacing*/
    normal_print("\n");

    /*prints the heading using puts*/
    puts(heading);

    /*loop for heading characters*/
    for (count = 0; count < strlen_heading; ++count) {
        normal_print("%s", "-");
    }

    /*menu display*/
    normal_print("\n");
    for (count = 0; count < NUM_MENU_CHOICES; ++count) {
        normal_print("%d) %s\n", count + 1, menu_list[count]);
    }
    /*****************END MENU DISPLAY*************************/

    /*******************START PROCESS MENU********************/
    /*ensure that 'end' has enough space and to thus prevent segmentation
     * faults*/
    end = SCREENWIDTH + EXTRACHARS;
    do {
        normal_print("Please enter your choice: ");
        /*read in the line and provide buffer management/limiting */
        fgets(line, end, stdin);

        /*test for buffer overflow. If buffer overflow is present, manage with
         * the provided overvlow management function*/
        if (line[strlen(line) - 1] != '\n') {
            clear_buffer();
            /*error_print("Buffer overflow!\n");*/
            /*continue;*/
        }
        success = TRUE;

    } while (success == FALSE);
    /*end boolean driven do while loop*/

    /*remove trailing newline-not needed any more*/
    line[strlen(line) - 1] = 0;

    /*conversion of input from a string to a integer using strtol*/
    /*note that the pointer address associated with ptr is referenced here*/
    input = strtol(line, &ptr, DECIMALINT);

    /*ensute input is a number*/
    /*note that the poimter assosciated withnptr is referenced here */
    if (*ptr != '\0') {
        error_print("Error: the given characters were not numeric.\n\n");
        return MC_INVALID;
    }

    /*error handling for numbers that are too small*/
    if (input < MIN_NUM_MENU_CHOICES) {
        error_print(
            "Error: %d is smaller than the boundary. Please enter a number "
            "between %d and %d. \n",
            input, MIN_NUM_MENU_CHOICES, NUM_MENU_CHOICES);
        return MC_INVALID;
    }

    /*error handling for numbers that are too big*/
    else if (input > NUM_MENU_CHOICES) {
        error_print(
            "Error: %d is larger than the boundary. Please enter a number "
            "between %d and %d. \n",
            input, MIN_NUM_MENU_CHOICES, NUM_MENU_CHOICES);
        return MC_INVALID;
    } else {
        /*subtract one due to the enum*/
        input--;
        result = input;
    }

    /*error for handling IR_FAILURE input*/
    /*IR_FAILURE return removed*/
    /*if (result == MC_INVALID) {
        error_print("Option couuld not be run successfully.\n");
        return MC_INVALID;
    }*/
    /********************END PROCESS MENU*********************/

    return result;
}

/**
 * for each of the requirements in part C you will need to create a function
 * here to handle user input. All user input should be handled from this module
 * and not from other modules. This makes it easier if we wish to change the
 * user interface.
 **/

/**
 * this function is a drop-in replacement for fprintf with stderr. You should
 * use this and not use fprintf in your code. The idea is that while this
 * does the same thing as printf, we could replace this such as with a gui
 * function and you would not need to change any other code for it to work.
 **/
int error_print(const char *format, ...) {
    va_list arglist;
    int count = 0;
    /* print out error preamble */
    count += fprintf(stderr, "Error: ");
    /* print out the rest of the args */
    va_start(arglist, format);
    count += vfprintf(stderr, format, arglist);
    va_end(arglist);
    return count;
}

/**
 * this function is a stand-in for printf. You should use this function rather
 * than printf. The idea is that we could replace this function with one
 * targeting another output and we would not have to change any other code for
 * this to work.
 **/
int normal_print(const char *format, ...) {
    int count = 0;
    /* prepare the argument list for output */
    va_list arglist;
    va_start(arglist, format);
    /* output the args */
    count += vprintf(format, arglist);
    /* cleanup */
    va_end(arglist);
    return count;
}

/**
 * function provided to you to make it easy to print out the item list from the
 * knapsack problem
 **/
void itemlist_print(const struct item_list *items) {
    int count;
    normal_print("The items in the list are: \n");
    for (count = 0; count < items->num_items; ++count) {
        const struct item *curitem = items->items + count;
        printf("item name: %s, cost: %d, weight: %d, count: %d\n",
               curitem->name, curitem->cost, curitem->weight, curitem->count);
    }
}
