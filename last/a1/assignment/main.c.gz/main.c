/******************************************************************************
 * Student Name    :
 * RMIT Student ID :
 *
 * Startup code provided by Paul Miller for use in "Programming in C",
 * Assignment 1, study period 4, 2020.
 *****************************************************************************/
#include <stdlib.h>
#include <stdio.h>

#include "imp.h"
#include "io.h"
#include "shared.h"
#include <string.h>


int main(void) {
    BOOLEAN quit = FALSE;
    /* hints for what to do in main() */
    /* have a loop that terminates when the user selects to exit the program */
    /* call display menu to get the user's choice of what they want to do */
    /* call the appropriate functions that handle user input in io.c */
    /* pass the user input into the appropriate function where that actual
     * option is implemented */
    /* replace this return with a correct return value and delete this comment
     */
    enum menu_choice choice;
    do {
        choice = display_menu();
        /*switch to send user choice to the right place*/
        switch (choice) {
            /*for later
            enum input_result another_result;
            char input[LINELEN + EXTRACHARS];
            */
            case MC_REVERSE: {
                normal_print("Welcome to reverse a word \n");
                break;
            }
            case MC_MAGSQ: {
                normal_print("Welcome to almost magic square\n");
                break;
            }
            case MC_GR_KNAP: {
                normal_print("Welcome to greedy knapsack solution");
                break;
            }
            case MC_BF_KNAP: {
                normal_print("Welcome to brute force greedy knapsack solution");
                break;
            }
            case MC_QUIT: {
                normal_print("Bye \n");
                quit = TRUE;
                break;
            }
            default: {
                assert(choice == MC_INVALID);
                error_print("Sorry, your choice is invalid");
            }
        }
        normal_print("\n");
    } while (quit == FALSE);
    return EXIT_SUCCESS;
}
