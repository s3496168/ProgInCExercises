/******************************************************************************
 * Student Name    :
 * RMIT Student ID :
 *
 * Startup code provided by Paul Miller for use in "Programming in C",
 * Assignment 1, study period 4, 2020.
 *****************************************************************************/

/*extra include to permit assertion*/
#include <assert.h>
#include <ctype.h>

#ifndef SHARED_H
#define SHARED_H
typedef enum {
    FALSE,
    TRUE
} BOOLEAN;
#endif
