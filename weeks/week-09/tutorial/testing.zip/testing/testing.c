
/*******************************************************************
File for testing functions needed for A2P2
*******************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include "testing.h"

/*added constants*/

#define NUMARGS 2
#define READING 1
#define WRITING 2

int main(int argc, char** argv) {
    FILE* fpRead;

    union readWrite test[SIZE];
    /*int result;*/

    /*zeroed out array*/
    memset(test, 0, sizeof(union readWrite) * SIZE);

    /* check the command line args */
    if (argc != NUMARGS) {
        perror("Error: the entrant is not a file type.");
        return EXIT_FAILURE;
    }
    printf("The amount of argc is: %d\n", argc);
    printf("The amount of argv[] is: %s\n", argv[1]);
    fpRead = gropen(argv[READING]);

    fclose(fpRead);

    return EXIT_SUCCESS;
}
